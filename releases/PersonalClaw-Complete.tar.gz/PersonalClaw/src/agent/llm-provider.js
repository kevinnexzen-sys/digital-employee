import Anthropic from '@anthropic-ai/sdk';
import OpenAI from 'openai';
import { createLogger } from '../utils/logger.js';
import config from '../utils/config.js';

const logger = createLogger('LLMProvider');

class LLMProvider {
  constructor() {
    this.anthropic = null;
    this.openai = null;
    this.initializeProviders();
  }

  initializeProviders() {
    // Initialize Anthropic
    if (config.anthropic.apiKey) {
      this.anthropic = new Anthropic({
        apiKey: config.anthropic.apiKey
      });
      logger.info('Anthropic initialized');
    } else {
      logger.warn('Anthropic API key not found');
    }

    // Initialize OpenAI
    if (config.openai.apiKey) {
      this.openai = new OpenAI({
        apiKey: config.openai.apiKey
      });
      logger.info('OpenAI initialized');
    } else {
      logger.warn('OpenAI API key not found');
    }
  }

  async chat(messages, options = {}) {
    const provider = options.provider || config.defaultLlmProvider;
    
    logger.info(`Sending chat request to ${provider}`);

    if (provider === 'anthropic') {
      return await this.chatAnthropic(messages, options);
    } else if (provider === 'openai') {
      return await this.chatOpenAI(messages, options);
    } else {
      throw new Error(`Unknown provider: ${provider}`);
    }
  }

  async chatAnthropic(messages, options = {}) {
    if (!this.anthropic) {
      throw new Error('Anthropic not initialized');
    }

    try {
      const response = await this.anthropic.messages.create({
        model: options.model || config.anthropic.model,
        max_tokens: options.maxTokens || 4096,
        messages: messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        system: options.system || 'You are PersonalClaw, a helpful AI assistant.',
        temperature: options.temperature || 0.7
      });

      return {
        content: response.content[0].text,
        model: response.model,
        usage: {
          inputTokens: response.usage.input_tokens,
          outputTokens: response.usage.output_tokens
        }
      };
    } catch (error) {
      logger.error('Anthropic error:', error);
      throw error;
    }
  }

  async chatOpenAI(messages, options = {}) {
    if (!this.openai) {
      throw new Error('OpenAI not initialized');
    }

    try {
      const response = await this.openai.chat.completions.create({
        model: options.model || config.openai.model,
        messages: messages,
        temperature: options.temperature || 0.7,
        max_tokens: options.maxTokens || 4096
      });

      return {
        content: response.choices[0].message.content,
        model: response.model,
        usage: {
          inputTokens: response.usage.prompt_tokens,
          outputTokens: response.usage.completion_tokens
        }
      };
    } catch (error) {
      logger.error('OpenAI error:', error);
      throw error;
    }
  }

  async streamChat(messages, options = {}, onChunk) {
    const provider = options.provider || config.defaultLlmProvider;
    
    logger.info(`Streaming chat request to ${provider}`);

    if (provider === 'anthropic') {
      return await this.streamChatAnthropic(messages, options, onChunk);
    } else if (provider === 'openai') {
      return await this.streamChatOpenAI(messages, options, onChunk);
    } else {
      throw new Error(`Unknown provider: ${provider}`);
    }
  }

  async streamChatAnthropic(messages, options = {}, onChunk) {
    if (!this.anthropic) {
      throw new Error('Anthropic not initialized');
    }

    try {
      const stream = await this.anthropic.messages.stream({
        model: options.model || config.anthropic.model,
        max_tokens: options.maxTokens || 4096,
        messages: messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        system: options.system || 'You are PersonalClaw, a helpful AI assistant.',
        temperature: options.temperature || 0.7
      });

      let fullContent = '';

      for await (const chunk of stream) {
        if (chunk.type === 'content_block_delta' && chunk.delta.type === 'text_delta') {
          const text = chunk.delta.text;
          fullContent += text;
          if (onChunk) {
            onChunk(text);
          }
        }
      }

      return { content: fullContent };
    } catch (error) {
      logger.error('Anthropic streaming error:', error);
      throw error;
    }
  }

  async streamChatOpenAI(messages, options = {}, onChunk) {
    if (!this.openai) {
      throw new Error('OpenAI not initialized');
    }

    try {
      const stream = await this.openai.chat.completions.create({
        model: options.model || config.openai.model,
        messages: messages,
        temperature: options.temperature || 0.7,
        max_tokens: options.maxTokens || 4096,
        stream: true
      });

      let fullContent = '';

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || '';
        if (content) {
          fullContent += content;
          if (onChunk) {
            onChunk(content);
          }
        }
      }

      return { content: fullContent };
    } catch (error) {
      logger.error('OpenAI streaming error:', error);
      throw error;
    }
  }
}

export default new LLMProvider();
