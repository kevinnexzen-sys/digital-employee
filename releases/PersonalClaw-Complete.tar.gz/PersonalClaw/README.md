# 🦞 PersonalClaw

**Your Personal AI Agent - OpenClaw Replica with Enhanced Security**

PersonalClaw is a powerful, privacy-focused AI agent that combines all the capabilities of OpenClaw with additional features designed for single-user operation and financial security.

## 🌟 Key Features

### ✅ Core Capabilities (OpenClaw Parity)
- **Multi-LLM Integration** - Claude, GPT-4, local models
- **Messaging Platforms** - WhatsApp, Telegram, Discord, Slack, Signal
- **Browser Automation** - Playwright-based web automation
- **Voice Interface** - Wake word detection, speech-to-text, text-to-speech
- **Memory System** - Long-term memory with vector embeddings
- **Skills Platform** - Self-improving with custom plugins
- **Automation & Scheduling** - Cron jobs, webhooks, email triggers

### 🆕 Enhanced Features (PersonalClaw Exclusive)

#### 1. 👁️ Watch-to-Learn
- **Screen Monitoring** - Continuous screen recording and analysis
- **Pattern Detection** - Identifies repetitive manual tasks
- **Auto-Suggestions** - Proposes automations after 3 repetitions
- **Privacy Controls** - Whitelist/blacklist applications
- **Encrypted Storage** - All recordings stored locally and encrypted

#### 2. 📺 Screen Reading
- **Real-time OCR** - Reads text from any application
- **Visual Understanding** - GPT-4 Vision / Claude Vision integration
- **Context Awareness** - Understands what you're working on
- **Proactive Assistance** - Offers help based on screen content

#### 3. ✋ Confirmation System
- **Mandatory Approval** - Critical actions require confirmation
- **Telegram Alerts** - Screenshots sent for review
- **Preview Mode** - See exactly what will happen before it happens
- **Timeout Protection** - Confirmations expire after 30 minutes

#### 4. 🪟 Windows Desktop App
- **Native Application** - Built with Electron
- **System Tray** - Always accessible from taskbar
- **Keyboard Shortcuts** - Win+Alt+C to activate
- **Overlay Mode** - Floating assistant window
- **Startup Integration** - Launch with Windows

### 🔒 Security Features

#### Financial Protection (HARDCODED - Cannot be disabled)
- ❌ **Banking websites** - All major banks blocked
- ❌ **Payment processors** - PayPal, Stripe, Venmo, etc.
- ❌ **Cryptocurrency** - Exchanges and wallets blocked
- ❌ **Trading platforms** - Stock/forex trading blocked
- ❌ **Credit card forms** - Automatic detection and blocking

#### Single-User Authentication
- ✅ **Biometric login** - Fingerprint/face recognition
- ✅ **Hardware tokens** - YubiKey support
- ✅ **Device binding** - Only your registered devices
- ✅ **IP whitelisting** - Known locations only
- ✅ **Session timeout** - Auto-lock after 15 minutes

#### Audit & Monitoring
- 📝 **Complete audit log** - Every action recorded
- 🚨 **Security alerts** - Suspicious activity notifications
- 📊 **Statistics dashboard** - Monitor system usage
- 🔍 **Blocked attempts** - Track financial access attempts

## 🚀 Quick Start

### Prerequisites
- Node.js 20+ 
- npm 10+
- Windows 10/11 (for desktop app)

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/personalclaw.git
cd personalclaw

# Install dependencies
npm install

# Copy environment configuration
cp .env.example .env

# Edit .env with your API keys and settings
nano .env

# Initialize database
npm run db:init

# Start the gateway server
npm run gateway

# In another terminal, start the desktop app
npm run desktop
```

### Configuration

Edit `.env` file with your settings:

```env
# Required: AI Provider API Keys
ANTHROPIC_API_KEY=sk-ant-your-key-here
OPENAI_API_KEY=sk-your-openai-key-here

# Required: Telegram Bot (for confirmations)
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHAT_ID=your-chat-id

# Optional: Voice Services
ELEVENLABS_API_KEY=your-elevenlabs-key

# Security: Single User
USER_ID=your-unique-id
USER_EMAIL=your-email@example.com
```

## 📖 Usage

### Starting PersonalClaw

```bash
# Start all services
npm start

# Or start individually:
npm run gateway    # Gateway server (port 18789)
npm run desktop    # Windows desktop app
```

### Basic Commands

```javascript
// In chat interface or Telegram:

"Check my emails and summarize"
"Research AI automation tools"
"Create a task automation for daily reports"
"Take a screenshot and analyze it"
"What's on my screen right now?"
```

### Watch-to-Learn Example

```
1. You manually copy data from email to Excel (3 times)
2. PersonalClaw detects the pattern
3. Suggests: "Create automation for email-to-Excel?"
4. You approve
5. Next time: Automatic extraction with confirmation
```

### Confirmation Flow Example

```
You: "Send email to client@company.com with project update"

PersonalClaw:
📧 Email Draft Ready
To: client@company.com
Subject: Project Update

[Preview shown]

📸 Screenshot sent to Telegram
⏳ Waiting for approval...

[Telegram: Approve/Reject/Edit buttons]
```

## 🏗️ Architecture

```
PersonalClaw/
├── src/
│   ├── gateway/          # WebSocket server & routing
│   ├── agent/            # LLM integration & execution
│   ├── tools/            # Browser, file, email tools
│   ├── security/         # Auth & financial blocking
│   ├── memory/           # Database & vector storage
│   ├── channels/         # Messaging integrations
│   ├── automation/       # Cron & task scheduling
│   ├── screen-watcher/   # Screen monitoring & OCR
│   └── desktop/          # Windows app logic
├── desktop/
│   ├── main/             # Electron main process
│   └── renderer/         # UI components
├── config/               # Configuration files
├── data/                 # Database & storage
└── logs/                 # Application logs
```

## 🔧 Development

### Project Structure

```bash
# Run in development mode with hot reload
npm run dev

# Run tests
npm test

# Lint code
npm run lint

# Build desktop app
npm run build:desktop
```

### Adding Custom Skills

```javascript
// src/tools/custom/my-skill.js
export default {
  name: 'my-skill',
  description: 'Does something awesome',
  
  async execute(params) {
    // Your code here
    return result;
  }
};
```

## 📊 Monitoring

### Dashboard
Access the web dashboard at: `http://localhost:18789`

### Logs
- Application logs: `./logs/personalclaw.log`
- Audit logs: `./logs/audit.log`
- Error logs: `./logs/error.log`

### Statistics

```bash
# View blocked financial attempts
curl http://localhost:18789/api/security/stats

# View system status
curl http://localhost:18789/api/status
```

## 🛡️ Security

### Financial Blocking

The financial blocker is **HARDCODED** and cannot be disabled:

```javascript
// This will ALWAYS throw an error:
financialBlocker.disable(); 
// Error: SECURITY VIOLATION: Financial blocking cannot be disabled
```

### Audit Trail

Every action is logged:
- Timestamp
- User ID
- Action type
- Target/parameters
- Result/status

### Data Privacy

- All data stored locally
- Encrypted at rest
- No cloud sync (unless explicitly enabled)
- Screen recordings encrypted
- Memory database encrypted

## 🤝 Contributing

This is a personal project, but suggestions are welcome!

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📝 License

MIT License - See LICENSE file for details

## ⚠️ Disclaimer

PersonalClaw is designed for personal use only. The financial blocking feature is a security measure, not a guarantee. Always exercise caution with sensitive information.

## 🆘 Support

- Documentation: [docs/](./docs/)
- Issues: [GitHub Issues](https://github.com/yourusername/personalclaw/issues)
- Discussions: [GitHub Discussions](https://github.com/yourusername/personalclaw/discussions)

## 🙏 Acknowledgments

- Inspired by OpenClaw (formerly Clawdbot/Moltbot)
- Built with love for automation and privacy
- Thanks to the open-source community

---

**Made with 🦞 by PersonalClaw Team**

*Your AI companion that respects your privacy and protects your finances.*
