# 📦 PersonalClaw - Complete Installation Guide

## 🎯 What You're Installing

PersonalClaw v2.0 - Enhanced AI Agent Framework with:
- ✅ Vector Search Memory
- ✅ Multi-Agent Swarm (5 workers)
- ✅ Self-Evolution System
- ✅ Always-On Voice (English, Bangla, Spanish)
- ✅ Animated Face Avatar
- ✅ Live Code Preview
- ✅ Multi-Language Support

---

## 📋 Prerequisites

### Required Software:
1. **Node.js 18+** - [Download](https://nodejs.org/)
2. **Python 3.9+** - [Download](https://python.org/)
3. **Git** - [Download](https://git-scm.com/)

### Required API Keys:
1. **Anthropic API Key** (for Claude) OR **OpenAI API Key** (for GPT-4)
2. **OpenAI API Key** (for embeddings - vector search)
3. **Telegram Bot Token** (optional - for Telegram integration)
4. **ElevenLabs API Key** (optional - for voice)

---

## 🚀 Installation Steps

### Step 1: Extract Archive

```bash
# Extract the archive
tar -xzf PersonalClaw-Complete.tar.gz

# Navigate to directory
cd PersonalClaw
```

### Step 2: Install Node.js Dependencies

```bash
# Install all Node.js packages
npm install

# Install Playwright browsers
npx playwright install chromium
```

### Step 3: Install Python Dependencies

```bash
# Install Python packages
pip3 install openai-whisper elevenlabs anthropic openai
```

### Step 4: Configure Environment Variables

```bash
# Copy example environment file
cp .env.example .env

# Edit .env file with your API keys
nano .env  # or use your preferred editor
```

**Required Configuration:**

```env
# LLM Provider (choose one)
LLM_PROVIDER=anthropic  # or 'openai'
ANTHROPIC_API_KEY=your_anthropic_key_here
OPENAI_API_KEY=your_openai_key_here

# Vector Search (required for hybrid search)
OPENAI_EMBEDDINGS_KEY=your_openai_key_here

# Telegram (optional)
TELEGRAM_BOT_TOKEN=your_telegram_token_here

# Voice (optional)
ELEVENLABS_API_KEY=your_elevenlabs_key_here

# Search Provider (optional)
SEARCH_PROVIDER=tavily  # or 'serpapi' or 'bing'
TAVILY_API_KEY=your_tavily_key_here
```

### Step 5: Initialize Database

```bash
# Create data directory
mkdir -p data

# Database will be created automatically on first run
```

### Step 6: Test Installation

```bash
# Test Node.js setup
node -v

# Test Python setup
python3 --version

# Test imports
node -e "console.log('Node.js OK')"
python3 -c "print('Python OK')"
```

---

## 🎮 Running PersonalClaw

### Option 1: Desktop App (Recommended)

```bash
# Start the desktop application
npm run desktop
```

**Features:**
- ✅ Full GUI interface
- ✅ Avatar window
- ✅ Live preview window
- ✅ Voice controls
- ✅ System tray integration

### Option 2: CLI Mode

```bash
# Start in command-line mode
npm start
```

**Features:**
- ✅ Text-based interface
- ✅ All core features
- ✅ Lower resource usage

### Option 3: Telegram Bot

```bash
# Start Telegram bot
npm run telegram
```

**Features:**
- ✅ Chat with PersonalClaw via Telegram
- ✅ Remote access
- ✅ Mobile support

---

## 🧪 Testing Features

### Test 1: Vector Search

```javascript
// In Node.js console or desktop app
const database = require('./src/memory/database.js');

// Add a memory
database.addMemory('I love programming in JavaScript', 8);

// Search memories
const results = await database.searchMemories('coding');
console.log(results);
```

### Test 2: Multi-Agent System

```javascript
const executor = require('./src/agent/executor.js');

// Execute a coding task
const result = await executor.execute('Write a function to calculate fibonacci');
console.log(result);
```

### Test 3: Voice Interface

```javascript
const voiceService = require('./src/voice/background-service.js');

// Start voice service
await voiceService.start();

// Check status
console.log(voiceService.getStatus());
```

### Test 4: Avatar

Open the desktop app and navigate to the Avatar window to see the animated face.

### Test 5: Live Preview

Open the desktop app and navigate to the Preview window to test real-time code rendering.

### Test 6: Multi-Language

```javascript
const translator = require('./src/i18n/translator.js');

// Switch to Bangla
translator.setLanguage('bn');
console.log(translator.translate('greeting'));

// Switch to Spanish
translator.setLanguage('es');
console.log(translator.translate('greeting'));
```

---

## 🔧 Troubleshooting

### Issue: "Module not found"

**Solution:**
```bash
# Reinstall dependencies
rm -rf node_modules
npm install
```

### Issue: "Playwright browser not found"

**Solution:**
```bash
# Reinstall Playwright browsers
npx playwright install chromium
```

### Issue: "Python module not found"

**Solution:**
```bash
# Reinstall Python packages
pip3 install --upgrade openai-whisper elevenlabs anthropic openai
```

### Issue: "Database locked"

**Solution:**
```bash
# Stop all PersonalClaw processes
pkill -f "node.*PersonalClaw"

# Remove lock file
rm -f data/personalclaw.db-wal
```

### Issue: "API key invalid"

**Solution:**
1. Check your `.env` file
2. Verify API keys are correct
3. Ensure no extra spaces or quotes
4. Restart PersonalClaw

---

## 📁 Directory Structure

```
PersonalClaw/
├── src/                    # Source code
│   ├── agent/             # AI agent & workers
│   ├── avatar/            # Animated face
│   ├── evolution/         # Self-improvement
│   ├── i18n/              # Multi-language
│   ├── memory/            # Database & vector search
│   ├── preview/           # Live preview
│   ├── voice/             # Voice interface
│   └── ...
├── desktop/               # Electron desktop app
│   ├── main.js           # Main process
│   ├── preload.js        # Secure IPC
│   └── renderer/         # UI windows
├── data/                  # Database & logs
├── skills/                # Generated skills
├── config/                # Configuration
├── .env                   # Environment variables
└── package.json           # Dependencies
```

---

## 🎯 Next Steps

1. **Explore Features:**
   - Try voice commands
   - Create custom skills
   - Test multi-agent tasks
   - Experiment with avatar expressions

2. **Customize:**
   - Add your own skills
   - Modify avatar appearance
   - Create custom workers
   - Add new languages

3. **Integrate:**
   - Connect to your calendar
   - Set up email integration
   - Configure Telegram bot
   - Add custom tools

---

## 📚 Additional Resources

- **Documentation:** See `SETUP_INSTRUCTIONS.md`
- **Security:** See `SECURITY_AUDIT_FIXES.md`
- **Features:** See `COMPLETE_BUILD_REPORT.md`
- **Tests:** See `FINAL_INTEGRATION_TEST.md`

---

## 🆘 Getting Help

**Issues?**
1. Check troubleshooting section above
2. Review log files in `logs/` directory
3. Verify all API keys are configured
4. Ensure all dependencies are installed

**Need Support?**
- Check documentation files
- Review test reports
- Verify system requirements

---

## ✅ Installation Checklist

- [ ] Node.js 18+ installed
- [ ] Python 3.9+ installed
- [ ] Archive extracted
- [ ] npm install completed
- [ ] Playwright browsers installed
- [ ] Python packages installed
- [ ] .env file configured
- [ ] API keys added
- [ ] Database directory created
- [ ] Test run successful

---

**Installation Complete!** 🎉

PersonalClaw v2.0 is now ready to use!

Run `npm run desktop` to start the desktop app.

---

**Version:** 2.0.0 (Enhanced)
**Last Updated:** March 13, 2024
