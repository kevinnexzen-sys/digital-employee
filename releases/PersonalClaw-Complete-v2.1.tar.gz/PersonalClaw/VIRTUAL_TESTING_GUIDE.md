# 🌐 PersonalClaw - Virtual Testing Environment

## 🎯 Test Before Download!

Before downloading PersonalClaw to your computer, you can test it virtually to ensure everything works correctly.

---

## 🖥️ OPTION 1: Online Code Sandbox (Recommended)

### Using CodeSandbox.io

1. **Visit:** https://codesandbox.io/
2. **Create Account:** Free account required
3. **Import Project:**
   - Click "Import Project"
   - Upload `PersonalClaw-Complete.tar.gz`
   - Wait for extraction

4. **Configure Environment:**
   - Open `.env` file
   - Add your API keys
   - Save changes

5. **Install Dependencies:**
   ```bash
   npm install
   ```

6. **Run Tests:**
   ```bash
   # Test imports
   node -e "console.log('Testing imports...')"
   
   # Test database
   node -e "const db = require('./src/memory/database.js'); console.log('Database OK')"
   ```

7. **Start Application:**
   ```bash
   npm start
   ```

**Pros:**
- ✅ No local installation needed
- ✅ Test in browser
- ✅ Share with others
- ✅ Free tier available

**Cons:**
- ⚠️ Limited resources
- ⚠️ No desktop app testing
- ⚠️ Requires internet

---

## 🐳 OPTION 2: Docker Container (Advanced)

### Using Docker

1. **Install Docker:**
   - Download from https://docker.com/

2. **Create Dockerfile:**
   ```dockerfile
   FROM node:18
   
   # Install Python
   RUN apt-get update && apt-get install -y python3 python3-pip
   
   # Set working directory
   WORKDIR /app
   
   # Copy project
   COPY . .
   
   # Install dependencies
   RUN npm install
   RUN pip3 install openai-whisper elevenlabs anthropic openai
   
   # Install Playwright
   RUN npx playwright install chromium --with-deps
   
   # Expose ports
   EXPOSE 3000 8080
   
   # Start command
   CMD ["npm", "start"]
   ```

3. **Build Image:**
   ```bash
   docker build -t personalclaw:test .
   ```

4. **Run Container:**
   ```bash
   docker run -it -p 3000:3000 -p 8080:8080 \
     -e ANTHROPIC_API_KEY=your_key \
     -e OPENAI_API_KEY=your_key \
     personalclaw:test
   ```

5. **Access:**
   - CLI: Inside container terminal
   - Web: http://localhost:3000

**Pros:**
- ✅ Isolated environment
- ✅ Easy cleanup
- ✅ Reproducible
- ✅ Full features

**Cons:**
- ⚠️ Requires Docker knowledge
- ⚠️ Resource intensive
- ⚠️ Setup time

---

## ☁️ OPTION 3: Cloud VM (Full Testing)

### Using Google Cloud Shell / AWS Cloud9

1. **Open Cloud Shell:**
   - Google Cloud: https://console.cloud.google.com/
   - AWS Cloud9: https://aws.amazon.com/cloud9/

2. **Upload Archive:**
   ```bash
   # Upload PersonalClaw-Complete.tar.gz
   # Extract
   tar -xzf PersonalClaw-Complete.tar.gz
   cd PersonalClaw
   ```

3. **Install Dependencies:**
   ```bash
   # Node.js (if not installed)
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Python packages
   pip3 install openai-whisper elevenlabs anthropic openai
   
   # Project dependencies
   npm install
   npx playwright install chromium
   ```

4. **Configure:**
   ```bash
   cp .env.example .env
   nano .env  # Add your API keys
   ```

5. **Test:**
   ```bash
   npm start
   ```

**Pros:**
- ✅ Full Linux environment
- ✅ All features work
- ✅ Free tier available
- ✅ Real testing

**Cons:**
- ⚠️ Requires cloud account
- ⚠️ Setup time
- ⚠️ May incur costs

---

## 🧪 OPTION 4: Local Virtual Machine

### Using VirtualBox / VMware

1. **Install VM Software:**
   - VirtualBox: https://virtualbox.org/
   - VMware: https://vmware.com/

2. **Create Ubuntu VM:**
   - Download Ubuntu 22.04 LTS
   - Create new VM (4GB RAM, 20GB disk)
   - Install Ubuntu

3. **Setup Environment:**
   ```bash
   # Update system
   sudo apt update && sudo apt upgrade -y
   
   # Install Node.js
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Install Python
   sudo apt install -y python3 python3-pip
   
   # Transfer and extract PersonalClaw
   tar -xzf PersonalClaw-Complete.tar.gz
   cd PersonalClaw
   
   # Install dependencies
   npm install
   pip3 install openai-whisper elevenlabs anthropic openai
   npx playwright install chromium --with-deps
   ```

4. **Configure & Run:**
   ```bash
   cp .env.example .env
   nano .env  # Add API keys
   npm run desktop  # Or npm start
   ```

**Pros:**
- ✅ Complete isolation
- ✅ Full desktop app testing
- ✅ No internet required (after setup)
- ✅ Safe testing

**Cons:**
- ⚠️ Resource intensive
- ⚠️ Long setup time
- ⚠️ Requires VM knowledge

---

## 🎮 QUICK TEST COMMANDS

Once you have PersonalClaw running in any environment, test these features:

### Test 1: Basic Functionality
```bash
node -e "console.log('PersonalClaw Test Suite'); console.log('Node.js:', process.version);"
```

### Test 2: Import Check
```bash
node -e "
const db = require('./src/memory/database.js');
const executor = require('./src/agent/executor.js');
console.log('✅ All imports working');
"
```

### Test 3: Database
```bash
node -e "
const db = require('./src/memory/database.js');
db.initialize();
db.addMemory('Test memory', 5);
console.log('✅ Database working');
"
```

### Test 4: Vector Search
```bash
node -e "
const vs = require('./src/memory/vector-search.js');
console.log('✅ Vector search module loaded');
"
```

### Test 5: Multi-Agent
```bash
node -e "
const wm = require('./src/agent/workers/worker-manager.js');
console.log('✅ Worker manager loaded');
console.log('Workers:', Object.keys(wm.workers));
"
```

---

## 📊 Testing Checklist

Before downloading to your computer, verify:

- [ ] Archive extracts successfully
- [ ] Dependencies install without errors
- [ ] Environment variables configured
- [ ] Database initializes
- [ ] All imports work
- [ ] No critical errors in logs
- [ ] Basic features functional
- [ ] API keys valid
- [ ] Memory system works
- [ ] Multi-agent system loads

---

## ⚠️ Common Testing Issues

### Issue: "Cannot find module"
**Solution:** Run `npm install` again

### Issue: "API key invalid"
**Solution:** Check `.env` file formatting

### Issue: "Playwright browser not found"
**Solution:** Run `npx playwright install chromium`

### Issue: "Permission denied"
**Solution:** Run with `sudo` or check file permissions

### Issue: "Port already in use"
**Solution:** Change port in config or kill existing process

---

## ✅ Ready to Download?

If all tests pass in your virtual environment:

1. ✅ Download `PersonalClaw-Complete.tar.gz`
2. ✅ Extract on your computer
3. ✅ Follow `INSTALLATION_GUIDE.md`
4. ✅ Use same configuration that worked in testing

---

## 🆘 Need Help?

**Testing Issues:**
1. Check logs in virtual environment
2. Verify all dependencies installed
3. Confirm API keys are valid
4. Review error messages

**Environment-Specific:**
- CodeSandbox: Check console output
- Docker: Check container logs (`docker logs`)
- Cloud VM: Check system logs
- Local VM: Check terminal output

---

## 📚 Additional Resources

- **Installation Guide:** `INSTALLATION_GUIDE.md`
- **Test Report:** `FINAL_INTEGRATION_TEST.md`
- **Build Report:** `COMPLETE_BUILD_REPORT.md`
- **Setup Instructions:** `SETUP_INSTRUCTIONS.md`

---

**Happy Testing!** 🧪

Test thoroughly in a virtual environment before downloading to ensure PersonalClaw works perfectly for your needs.

---

**Version:** 2.0.0 (Enhanced)
**Last Updated:** March 13, 2024
