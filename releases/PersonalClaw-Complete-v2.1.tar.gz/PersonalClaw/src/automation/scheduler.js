import { createLogger } from '../utils/logger.js';
import cron from 'node-cron';

const logger = createLogger('Scheduler');

class Scheduler {
  constructor() {
    this.jobs = new Map();
    this.isRunning = false;
  }

  /**
   * Start the scheduler
   */
  start() {
    if (this.isRunning) {
      logger.warn('Scheduler already running');
      return;
    }

    this.isRunning = true;
    logger.info('Scheduler started');
  }

  /**
   * Stop the scheduler
   */
  stop() {
    if (!this.isRunning) {
      logger.warn('Scheduler not running');
      return;
    }

    // Stop all jobs
    for (const [id, job] of this.jobs.entries()) {
      job.stop();
      logger.info(`Stopped job: ${id}`);
    }

    this.jobs.clear();
    this.isRunning = false;
    logger.info('Scheduler stopped');
  }

  /**
   * Schedule a new job
   * @param {string} id - Unique job identifier
   * @param {string} cronExpression - Cron expression (e.g., '0 9 * * *' for 9 AM daily)
   * @param {Function} task - Function to execute
   * @param {Object} options - Additional options
   */
  scheduleJob(id, cronExpression, task, options = {}) {
    if (this.jobs.has(id)) {
      logger.warn(`Job ${id} already exists, removing old job`);
      this.removeJob(id);
    }

    try {
      const job = cron.schedule(cronExpression, async () => {
        logger.info(`Executing scheduled job: ${id}`);
        try {
          await task();
          logger.info(`Job ${id} completed successfully`);
        } catch (error) {
          logger.error(`Job ${id} failed:`, error);
        }
      }, {
        scheduled: true,
        timezone: options.timezone || 'UTC'
      });

      this.jobs.set(id, job);
      logger.info(`Scheduled job: ${id} with cron: ${cronExpression}`);
      
      return true;
    } catch (error) {
      logger.error(`Failed to schedule job ${id}:`, error);
      return false;
    }
  }

  /**
   * Remove a scheduled job
   * @param {string} id - Job identifier
   */
  removeJob(id) {
    const job = this.jobs.get(id);
    if (job) {
      job.stop();
      this.jobs.delete(id);
      logger.info(`Removed job: ${id}`);
      return true;
    }
    
    logger.warn(`Job ${id} not found`);
    return false;
  }

  /**
   * Get all scheduled jobs
   */
  getJobs() {
    return Array.from(this.jobs.keys());
  }

  /**
   * Check if a job exists
   * @param {string} id - Job identifier
   */
  hasJob(id) {
    return this.jobs.has(id);
  }

  /**
   * Schedule common automation patterns
   */
  scheduleDaily(id, hour, minute, task) {
    return this.scheduleJob(id, `${minute} ${hour} * * *`, task);
  }

  scheduleWeekly(id, dayOfWeek, hour, minute, task) {
    return this.scheduleJob(id, `${minute} ${hour} * * ${dayOfWeek}`, task);
  }

  scheduleMonthly(id, dayOfMonth, hour, minute, task) {
    return this.scheduleJob(id, `${minute} ${hour} ${dayOfMonth} * *`, task);
  }

  scheduleEveryMinute(id, task) {
    return this.scheduleJob(id, '* * * * *', task);
  }

  scheduleEveryHour(id, task) {
    return this.scheduleJob(id, '0 * * * *', task);
  }
}

export default new Scheduler();
