import { createLogger } from '../utils/logger.js';
import express from 'express';
import crypto from 'crypto';

const logger = createLogger('WebhookHandler');

class WebhookHandler {
  constructor() {
    this.app = null;
    this.server = null;
    this.webhooks = new Map();
    this.port = process.env.WEBHOOK_PORT || 8081;
  }

  /**
   * Start webhook server
   */
  start() {
    if (this.server) {
      logger.warn('Webhook server already running');
      return;
    }

    this.app = express();
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));

    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({ status: 'ok', webhooks: this.webhooks.size });
    });

    // Generic webhook endpoint
    this.app.post('/webhook/:id', async (req, res) => {
      const webhookId = req.params.id;
      const webhook = this.webhooks.get(webhookId);

      if (!webhook) {
        logger.warn(`Webhook not found: ${webhookId}`);
        return res.status(404).json({ error: 'Webhook not found' });
      }

      // Verify signature if secret is set
      if (webhook.secret) {
        const signature = req.headers['x-webhook-signature'];
        if (!this.verifySignature(req.body, signature, webhook.secret)) {
          logger.warn(`Invalid signature for webhook: ${webhookId}`);
          return res.status(401).json({ error: 'Invalid signature' });
        }
      }

      try {
        logger.info(`Received webhook: ${webhookId}`);
        const result = await webhook.handler(req.body, req.headers);
        res.json({ success: true, result });
      } catch (error) {
        logger.error(`Webhook ${webhookId} failed:`, error);
        res.status(500).json({ error: error.message });
      }
    });

    this.server = this.app.listen(this.port, () => {
      logger.info(`Webhook server listening on port ${this.port}`);
    });
  }

  /**
   * Stop webhook server
   */
  stop() {
    if (this.server) {
      this.server.close();
      this.server = null;
      this.app = null;
      logger.info('Webhook server stopped');
    }
  }

  /**
   * Register a new webhook
   * @param {string} id - Unique webhook identifier
   * @param {Function} handler - Function to handle webhook data
   * @param {Object} options - Additional options (secret, etc.)
   */
  registerWebhook(id, handler, options = {}) {
    if (this.webhooks.has(id)) {
      logger.warn(`Webhook ${id} already exists, overwriting`);
    }

    this.webhooks.set(id, {
      handler,
      secret: options.secret,
      createdAt: new Date()
    });

    const url = `http://localhost:${this.port}/webhook/${id}`;
    logger.info(`Registered webhook: ${id} at ${url}`);
    
    return url;
  }

  /**
   * Remove a webhook
   * @param {string} id - Webhook identifier
   */
  removeWebhook(id) {
    if (this.webhooks.delete(id)) {
      logger.info(`Removed webhook: ${id}`);
      return true;
    }
    
    logger.warn(`Webhook ${id} not found`);
    return false;
  }

  /**
   * Get all registered webhooks
   */
  getWebhooks() {
    return Array.from(this.webhooks.keys());
  }

  /**
   * Verify webhook signature
   * @param {Object} payload - Webhook payload
   * @param {string} signature - Signature from header
   * @param {string} secret - Webhook secret
   */
  verifySignature(payload, signature, secret) {
    if (!signature) return false;

    const hmac = crypto.createHmac('sha256', secret);
    const digest = hmac.update(JSON.stringify(payload)).digest('hex');
    
    return signature === digest;
  }

  /**
   * Generate signature for outgoing webhooks
   * @param {Object} payload - Webhook payload
   * @param {string} secret - Webhook secret
   */
  generateSignature(payload, secret) {
    const hmac = crypto.createHmac('sha256', secret);
    return hmac.update(JSON.stringify(payload)).digest('hex');
  }
}

export default new WebhookHandler();
