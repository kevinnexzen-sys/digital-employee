import { createLogger } from '../utils/logger.js';
import scheduler from './scheduler.js';
import webhookHandler from './webhook-handler.js';
import emailTriggers from './email-triggers.js';
import database from '../memory/database.js';

const logger = createLogger('AutomationManager');

class AutomationManager {
  constructor() {
    this.isInitialized = false;
    this.automations = new Map();
  }

  /**
   * Initialize automation system
   */
  async initialize() {
    if (this.isInitialized) {
      logger.warn('Automation manager already initialized');
      return;
    }

    try {
      // Start scheduler
      scheduler.start();
      
      // Start webhook handler
      webhookHandler.start();
      
      // Initialize email triggers
      await emailTriggers.initialize();
      
      // Load saved automations from database
      await this.loadAutomations();
      
      this.isInitialized = true;
      logger.info('Automation manager initialized');
    } catch (error) {
      logger.error('Failed to initialize automation manager:', error);
      throw error;
    }
  }

  /**
   * Shutdown automation system
   */
  shutdown() {
    scheduler.stop();
    webhookHandler.stop();
    this.automations.clear();
    this.isInitialized = false;
    logger.info('Automation manager shutdown');
  }

  /**
   * Create a new automation
   * @param {Object} config - Automation configuration
   */
  async createAutomation(config) {
    const id = config.id || `auto_${Date.now()}`;
    
    const automation = {
      id,
      name: config.name,
      type: config.type, // 'schedule', 'webhook', 'email'
      trigger: config.trigger,
      action: config.action,
      enabled: config.enabled !== false,
      createdAt: new Date()
    };

    // Register based on type
    switch (config.type) {
      case 'schedule':
        scheduler.scheduleJob(id, config.trigger.cron, async () => {
          await this.executeAction(automation);
        });
        break;
        
      case 'webhook':
        webhookHandler.registerWebhook(id, async (data) => {
          await this.executeAction(automation, data);
        }, { secret: config.trigger.secret });
        break;
        
      case 'email':
        emailTriggers.registerTrigger(id, config.trigger, async (email) => {
          await this.executeAction(automation, email);
        });
        break;
        
      default:
        throw new Error(`Unknown automation type: ${config.type}`);
    }

    this.automations.set(id, automation);
    
    // Save to database
    await this.saveAutomation(automation);
    
    logger.info(`Created automation: ${id} (${config.type})`);
    return automation;
  }

  /**
   * Execute automation action
   * @param {Object} automation - Automation object
   * @param {Object} data - Trigger data
   */
  async executeAction(automation, data = {}) {
    if (!automation.enabled) {
      logger.info(`Automation ${automation.id} is disabled, skipping`);
      return;
    }

    logger.info(`Executing automation: ${automation.id}`);
    
    try {
      const action = automation.action;
      
      switch (action.type) {
        case 'execute_skill':
          // Execute a skill
          logger.info(`Executing skill: ${action.skillName}`);
          // TODO: Integrate with skills engine
          break;
          
        case 'send_email':
          await emailTriggers.sendEmail({
            to: action.to,
            subject: action.subject,
            text: action.message
          });
          break;
          
        case 'webhook':
          // Send webhook
          logger.info(`Sending webhook to: ${action.url}`);
          // TODO: Implement webhook sending
          break;
          
        case 'custom':
          // Execute custom function
          if (typeof action.handler === 'function') {
            await action.handler(data);
          }
          break;
          
        default:
          logger.warn(`Unknown action type: ${action.type}`);
      }
      
      logger.info(`Automation ${automation.id} executed successfully`);
    } catch (error) {
      logger.error(`Automation ${automation.id} failed:`, error);
    }
  }

  /**
   * Delete an automation
   * @param {string} id - Automation identifier
   */
  async deleteAutomation(id) {
    const automation = this.automations.get(id);
    if (!automation) {
      logger.warn(`Automation ${id} not found`);
      return false;
    }

    // Remove from respective handler
    switch (automation.type) {
      case 'schedule':
        scheduler.removeJob(id);
        break;
      case 'webhook':
        webhookHandler.removeWebhook(id);
        break;
      case 'email':
        emailTriggers.removeTrigger(id);
        break;
    }

    this.automations.delete(id);
    
    // Remove from database
    database.run('DELETE FROM automations WHERE id = ?', [id]);
    
    logger.info(`Deleted automation: ${id}`);
    return true;
  }

  /**
   * Enable/disable an automation
   * @param {string} id - Automation identifier
   * @param {boolean} enabled - Enable or disable
   */
  async toggleAutomation(id, enabled) {
    const automation = this.automations.get(id);
    if (!automation) {
      logger.warn(`Automation ${id} not found`);
      return false;
    }

    automation.enabled = enabled;
    await this.saveAutomation(automation);
    
    logger.info(`Automation ${id} ${enabled ? 'enabled' : 'disabled'}`);
    return true;
  }

  /**
   * Get all automations
   */
  getAutomations() {
    return Array.from(this.automations.values());
  }

  /**
   * Get automation by ID
   * @param {string} id - Automation identifier
   */
  getAutomation(id) {
    return this.automations.get(id);
  }

  /**
   * Save automation to database
   * @param {Object} automation - Automation object
   */
  async saveAutomation(automation) {
    const data = JSON.stringify({
      trigger: automation.trigger,
      action: automation.action,
      enabled: automation.enabled
    });

    database.run(
      'INSERT OR REPLACE INTO automations (id, name, type, data, created_at) VALUES (?, ?, ?, ?, ?)',
      [automation.id, automation.name, automation.type, data, automation.createdAt.toISOString()]
    );
  }

  /**
   * Load automations from database
   */
  async loadAutomations() {
    const rows = database.all('SELECT * FROM automations');
    
    for (const row of rows) {
      try {
        const data = JSON.parse(row.data);
        await this.createAutomation({
          id: row.id,
          name: row.name,
          type: row.type,
          trigger: data.trigger,
          action: data.action,
          enabled: data.enabled
        });
      } catch (error) {
        logger.error(`Failed to load automation ${row.id}:`, error);
      }
    }
    
    logger.info(`Loaded ${rows.length} automations from database`);
  }
}

export default new AutomationManager();
