import { createLogger } from '../utils/logger.js';
import nodemailer from 'nodemailer';

const logger = createLogger('EmailTriggers');

class EmailTriggers {
  constructor() {
    this.triggers = new Map();
    this.transporter = null;
    this.isMonitoring = false;
  }

  /**
   * Initialize email service
   */
  async initialize() {
    try {
      // Create email transporter
      this.transporter = nodemailer.createTransporter({
        host: process.env.EMAIL_HOST || 'smtp.gmail.com',
        port: process.env.EMAIL_PORT || 587,
        secure: false,
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASSWORD
        }
      });

      // Verify connection
      await this.transporter.verify();
      logger.info('Email service initialized');
      return true;
    } catch (error) {
      logger.error('Failed to initialize email service:', error);
      return false;
    }
  }

  /**
   * Register an email trigger
   * @param {string} id - Unique trigger identifier
   * @param {Object} config - Trigger configuration
   * @param {Function} handler - Function to execute when triggered
   */
  registerTrigger(id, config, handler) {
    if (this.triggers.has(id)) {
      logger.warn(`Trigger ${id} already exists, overwriting`);
    }

    this.triggers.set(id, {
      config: {
        from: config.from,
        subject: config.subject,
        keywords: config.keywords || [],
        attachments: config.attachments || false
      },
      handler,
      createdAt: new Date()
    });

    logger.info(`Registered email trigger: ${id}`);
    return true;
  }

  /**
   * Remove an email trigger
   * @param {string} id - Trigger identifier
   */
  removeTrigger(id) {
    if (this.triggers.delete(id)) {
      logger.info(`Removed trigger: ${id}`);
      return true;
    }
    
    logger.warn(`Trigger ${id} not found`);
    return false;
  }

  /**
   * Send an email
   * @param {Object} options - Email options
   */
  async sendEmail(options) {
    if (!this.transporter) {
      throw new Error('Email service not initialized');
    }

    try {
      const info = await this.transporter.sendMail({
        from: options.from || process.env.EMAIL_USER,
        to: options.to,
        subject: options.subject,
        text: options.text,
        html: options.html,
        attachments: options.attachments
      });

      logger.info(`Email sent: ${info.messageId}`);
      return info;
    } catch (error) {
      logger.error('Failed to send email:', error);
      throw error;
    }
  }

  /**
   * Check if email matches trigger criteria
   * @param {Object} email - Email object
   * @param {Object} trigger - Trigger configuration
   */
  matchesTrigger(email, trigger) {
    const config = trigger.config;

    // Check sender
    if (config.from && !email.from.includes(config.from)) {
      return false;
    }

    // Check subject
    if (config.subject && !email.subject.includes(config.subject)) {
      return false;
    }

    // Check keywords
    if (config.keywords.length > 0) {
      const content = `${email.subject} ${email.text}`.toLowerCase();
      const hasKeyword = config.keywords.some(keyword => 
        content.includes(keyword.toLowerCase())
      );
      if (!hasKeyword) return false;
    }

    // Check attachments
    if (config.attachments && !email.attachments) {
      return false;
    }

    return true;
  }

  /**
   * Process incoming email
   * @param {Object} email - Email object
   */
  async processEmail(email) {
    logger.info(`Processing email from: ${email.from}`);

    for (const [id, trigger] of this.triggers.entries()) {
      if (this.matchesTrigger(email, trigger)) {
        logger.info(`Email matched trigger: ${id}`);
        
        try {
          await trigger.handler(email);
          logger.info(`Trigger ${id} executed successfully`);
        } catch (error) {
          logger.error(`Trigger ${id} failed:`, error);
        }
      }
    }
  }

  /**
   * Get all registered triggers
   */
  getTriggers() {
    return Array.from(this.triggers.keys());
  }

  /**
   * Send notification email
   * @param {string} to - Recipient email
   * @param {string} subject - Email subject
   * @param {string} message - Email message
   */
  async sendNotification(to, subject, message) {
    return this.sendEmail({
      to,
      subject,
      text: message,
      html: `<p>${message}</p>`
    });
  }
}

export default new EmailTriggers();
